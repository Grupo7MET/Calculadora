package edu.grupo7.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button b1;
    private Button b2;
    private Button b3;
    private Button b4;
    private Button b5;
    private Button b6;
    private Button b7;
    private Button b8;
    private Button b9;
    private Button b0;
    private Button b00;
    private Button bc;
    private Button bce;
    private Button bMas;
    private Button bMenos;
    private Button bIgual;
    private Button bPor;
    private Button bEntre;
    private Button bComa;
    private TextView tvOut;
    private float result;
    private float op1;
    private float op2;
    private char operand;
    private boolean active;
    private boolean eliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);
        b5 = (Button) findViewById(R.id.b5);
        b6 = (Button) findViewById(R.id.b6);
        b7 = (Button) findViewById(R.id.b7);
        b8 = (Button) findViewById(R.id.b8);
        b9 = (Button) findViewById(R.id.b9);
        b0 = (Button) findViewById(R.id.b0);
        b00 = (Button) findViewById(R.id.b00);
        bc = (Button) findViewById(R.id.bc);
        bce = (Button) findViewById(R.id.bce);
        bMas = (Button) findViewById(R.id.bMas);
        bMenos = (Button) findViewById(R.id.bMenos);
        bIgual = (Button) findViewById(R.id.bIgual);
        bPor = (Button) findViewById(R.id.bPor);
        bEntre = (Button) findViewById(R.id.bEntre);
        bComa = (Button) findViewById(R.id.bComa);
        tvOut = (TextView) findViewById(R.id.tvRespuesta);

        active = false;
        eliminar = false;
        operand = '+';
        op1 = 0;
        op2 = 0;
        result = 0;

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b1.getText());
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b2.getText());
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b3.getText());
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b4.getText());
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b5.getText());
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b6.getText());
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b7.getText());
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b8.getText());
            }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b9.getText());
            }
        });

        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b0.getText());
            }
        });

        b00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eliminar){
                    tvOut.setText("");
                    eliminar = false;
                }
                tvOut.setText(tvOut.getText().toString() + b00.getText());
            }
        });

        bIgual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!active){
                    if (tvOut.getText().toString().equals("")){
                        result = 0;
                    }else{
                        result = Float.parseFloat(tvOut.getText().toString());
                    }
                    tvOut.setText(String.valueOf(result));
                    eliminar = true;
                }else{
                    switch (operand){
                        case '+':
                            if (tvOut.getText().toString().equals("") || eliminar){
                                op2 = 0;
                            }else{
                                op2 = Float.parseFloat(tvOut.getText().toString());
                            }
                            result = op1 + op2;
                            tvOut.setText(String.valueOf(result));
                            break;

                        case '-':
                            if (tvOut.getText().toString().equals("") || eliminar){
                                op2 = 0;
                            }else{
                                op2 = Float.parseFloat(tvOut.getText().toString());
                            }
                            result = op1-op2;
                            tvOut.setText(String.valueOf(result));
                            break;

                        case '*':
                            if (tvOut.getText().toString().equals("") || eliminar){
                                op2 = 1;
                            }else{
                                op2 = Float.parseFloat(tvOut.getText().toString());
                            }
                            result = op1*op2;
                            tvOut.setText(String.valueOf(result));
                            break;

                        case '/':
                            if (tvOut.getText().toString().equals("") || eliminar){
                                op2 = 1;
                            }else{
                                op2 = Float.parseFloat(tvOut.getText().toString());
                            }
                            if(op2 == 0){
                                result = 99999;
                                tvOut.setText("Infinite");
                            }else{
                                result = op1/op2;
                                tvOut.setText(String.valueOf(result));
                            }
                            break;
                    }
                    eliminar = true;
                    op1 = result;
                    op2 = 0;
                    operand = '+';
                }
            }
        });

        bc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvOut.setText("");
            }
        });

        bce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvOut.setText("");
                op1 = 0;
                op2 = 0;
                result = 0;
                eliminar = false;
                active = false;
            }
        });

        bComa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvOut.setText(tvOut.getText().toString() + bComa.getText());
            }
        });

        bPor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operand = '*';
                if (!active){
                    //Si es el primer operador...
                    if(tvOut.getText().toString().equals("")){
                        op1 = 0;
                    }else {
                        op1 = Float.parseFloat(tvOut.getText().toString());
                    }
                    active = true;
                    eliminar = true;
                }else{
                    //Si ya es el segundo...
                    if(tvOut.getText().toString().equals("") || eliminar){
                        op2 = 1;
                    }else {
                        op2 = Float.parseFloat(tvOut.getText().toString());
                    }

                    result = op1*op2;
                    tvOut.setText(String.valueOf(result));
                    op1 = result;
                    op2 = 1;
                    eliminar = true;
                }
                tvOut.setText(tvOut.getText().toString() + "*");
            }
        });

        bEntre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operand = '/';
                if (!active){
                    //Si es el primer operador...
                    if(tvOut.getText().toString().equals("")){
                        op1 = 0;
                    }else {
                        op1 = Float.parseFloat(tvOut.getText().toString());
                    }
                    active = true;
                    eliminar = true;
                }else{
                    //Si ya es el segundo...
                    if(tvOut.getText().toString().equals("") || eliminar){
                        op2 = 1;
                    }else {
                        op2 = Float.parseFloat(tvOut.getText().toString());
                    }
                    if(op2 == 0){
                        result = 99999;
                        tvOut.setText("Infinite");
                    }else {
                        result = op1 / op2;
                        tvOut.setText(String.valueOf(result));
                    }
                    op1 = result;
                    op2 = 1;
                    eliminar = true;
                }
                tvOut.setText(tvOut.getText().toString() + bEntre.getText());
            }
        });

        bMas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operand = '+';
                if (!active){
                    //Si es el primer operador...
                    if(tvOut.getText().toString().equals("")){
                        op1 = 0;
                    }else {
                        op1 = Float.parseFloat(tvOut.getText().toString());
                    }
                    active = true;
                    eliminar = true;
                }else{
                    //Si ya es el segundo...
                    if(tvOut.getText().toString().equals("") || eliminar){
                        op2 = 0;
                    }else {
                        op2 = Float.parseFloat(tvOut.getText().toString());
                    }

                    result = op1+op2;
                    tvOut.setText(String.valueOf(result));
                    op1 = result;
                    op2 = 0;
                    eliminar = true;
                }
                tvOut.setText(tvOut.getText().toString() + bMas.getText());
            }
        });

        bMenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operand = '-';
                if (!active){
                    //Si es el primer operador...
                    if(tvOut.getText().toString().equals("")){
                        op1 = 0;
                    }else {
                        op1 = Float.parseFloat(tvOut.getText().toString());
                    }
                    active = true;
                    eliminar = true;
                }else{
                    //Si ya es el segundo...
                    if(tvOut.getText().toString().equals("") || eliminar){
                        op2 = 0;
                    }else {
                        op2 = Float.parseFloat(tvOut.getText().toString());
                    }
                    result = op1-op2;
                    tvOut.setText(String.valueOf(result));
                    op1 = result;
                    op2 = 0;
                    eliminar = true;
                }
                tvOut.setText(tvOut.getText().toString() + bMenos.getText());
            }
        });

    }
}